def make_decision(objects, sensor_data):
    if "red_object" in objects:
        if sensor_data["distance"] < 1.0:
            return "Stop - Object too close"
        else:
            return "Move Forward - Object detected"
    return "Search - No object"