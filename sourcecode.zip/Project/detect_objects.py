import cv2
import numpy as np

# Dummy model; replace with your actual model (e.g., TensorFlow/YOLO)
def detect_objects(frame):
    # For demo: detect if red color is in frame (mock object detection)
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_red = np.array([0, 120, 70])
    upper_red = np.array([10, 255, 255])
    mask = cv2.inRange(hsv, lower_red, upper_red)
    
    if cv2.countNonZero(mask) > 500:
        return ["red_object"]
    return []
