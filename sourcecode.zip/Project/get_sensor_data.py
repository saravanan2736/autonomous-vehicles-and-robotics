import random

def get_sensor_data():
    # Mock sensor data for now
    return {
        "distance": random.uniform(0.5, 5.0),  # meters
        "temperature": random.uniform(20, 35),  # Celsius
        "light": random.randint(100, 1000)  # Lux
    }
