import cv2
from get_sensor_data import get_sensor_data
from detect_objects import detect_objects
from decision import make_decision

def main():
    cap = cv2.VideoCapture(0)  # Use webcam
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        objects = detect_objects(frame)
        sensor_data = get_sensor_data()
        action = make_decision(objects, sensor_data)

        print(f"[ACTION] {action}")
        cv2.imshow("Robot Vision", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "_main_":
    main()
